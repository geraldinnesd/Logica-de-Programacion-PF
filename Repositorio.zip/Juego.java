//para interfaces y clases
	import java.util.*;
	import java.util.Arrays; 

public class Juego

{ public static void imprimirFila(String fila[]) //darle colores a las matrices de números que hicimos
	{
		for (int i=0;i<fila.length;i++) {
			
	 		if(fila[i].equals("1"))
	 		{
	 			System.out.print(ConsoleColors.RED_BACKGROUND+"  ");
	 		}
	 		if(fila[i].equals("2"))
	 		{
	 			System.out.print(ConsoleColors.BLUE_BACKGROUND+"  ");
	 		}
	 		if(fila[i].equals("3"))
	 		{
	 			System.out.print(ConsoleColors.WHITE_BACKGROUND+"  ");
	 		}
	 		if(fila[i].equals("4"))
	 		{
	 			System.out.print(ConsoleColors.YELLOW_BACKGROUND+"  ");
	 		}		 		
		}
		System.out.println(ConsoleColors.RESET);
	}

	public static int subMenuSeleccionBandera(int[] indices)
	{
		int opc = 0;

		do{
			System.out.println("Ingrese un valor entre 1 y "+indices.length);
			opc = ConsoleInput.getInt();
		}while(opc<0 || opc==0 || opc>indices.length);

		return opc-1;
	}
	
	public static void imprimirGraficoBandera(String[] banderas, int indice)
	{
		for (int i=indice;i<indice+20;i++ ) //las matrices de las banderas avanzan de a 20
		{
			imprimirFila(banderas[i].split(";"));
		}
			
	}

	public static void imprimirInformacionBandera(String[] banderas,int indice)
	{
		String fila[];

		for (int i=indice;i<indice+20;i++ ) {
			if(i == indice)
			{
				fila = banderas[i].split(";");
				System.out.println("Nombre pais: "+fila[0]);
				/*System.out.println("Capital: "+fila[1]);
				System.out.println("Idioma: "+fila[2]);*/
			}
			else{
				System.out.println(banderas[i]);
			}
		}
	}
	

public class Enunciado{

	//Decoracion con ascii art
	//Funcion que permita imprimir caracteres del español, ejemplo ñ
					}

	public static void jugar()
	{
		String a,b,c,d;

		System.out.println(":: Jugar ::");
		System.out.println("Aquí se imprime la la bandera");
		System.out.println("Para visitar a este país tenemos 8 cupos disponibles");
		System.out.println("dependiendo de tu respuesta te decimos si viajas o no viajas");
		System.out.println("Selecciona lo primero que llevarías");
		System.out.println("1. Coco");
		System.out.println("2. Cuchillo");
		System.out.println("3. Armadillo");
		System.out.println("4. Colonia");

		int centinela_;
		do
		{
			centinela_ = ConsoleInput.getInt();
				switch(centinela_)
			{
				case 1:	System.out.println("Viajas");
						break;
				case 2: System.out.println("Viajas");
						break;
				case 3: System.out.println("No viajas");
						break;
				case 4: System.out.println("No viajas");
						break;
				default: System.out.println("Opcion no disponible");
						break;
			}

		}while(centinela_!=5);

		


		/*a = ConsoleInput.getString();

		b =	ConsoleInput.getString();
		c =	ConsoleInput.getString();
		d =	ConsoleInput.getString();*/

		

		//System.out.println(a); //
	}
	public static void instrucciones()
	{
		System.out.println("Estas son adivinanzas");
		
	}
	public static void acerca_de()
	{
		System.out.println("Los autores están perdidos");
		
	}
	public static int[] crearIndices(int total)
	{
		int indices[] = new int[total];
		int contador = 0;
		for (int i=0;i<indices.length;i++) {
			indices[i] = contador;
			contador+=20;		
		}
		return indices;
	}






	


	public static void menu()

	{
		int centinela = 0, opcion_bandera = 0;
		String banderas[] = ConsoleFile.read("recursos/info_banderas.csv");
		int indices[] = crearIndices(banderas.length/20);
		
	
		
		do
		{
			System.out.println();
			System.out.println(ConsoleColors.YELLOW+"  "+ " ___  _                 _       ");
			System.out.println(ConsoleColors.YELLOW+"  "+ "|  _|| | ___  ___  _ _ |_| ___  ___");
			System.out.println(ConsoleColors.YELLOW+"  "+ "|  _|| || .'|| . || | || ||   || . |");
			System.out.println(ConsoleColors.YELLOW+"  "+ "|  _|| || .'|| . || | || ||   || . |");
			System.out.println(ConsoleColors.YELLOW+"  "+ "|_|  |_||__,||_  ||_  ||_||_|_||_  |");
			System.out.println(ConsoleColors.YELLOW+"  "+ "             |___||___|        |___|");

			System.out.println("Escoja una opción");
			System.out.println("1. Bandera con la que voy a jugar");
			System.out.println("2. Instrucciones");
			System.out.println("3. Acerca de");
			System.out.println("4. Salir");
			centinela = ConsoleInput.getInt();

			switch(centinela)
			{
				case 1:	System.out.println();
				 		jugar();
						break;
				case 2: System.out.println();
						instrucciones();
						break;
				case 3: System.out.println();
						acerca_de();
						break;
				case 4: System.out.println("Sayonara");
						break;
				default: System.out.println("Opcion no disponible");
			}

		}while(centinela!=4);
	}
	public static void main(String args[])
	{
		menu();
		

	}
}